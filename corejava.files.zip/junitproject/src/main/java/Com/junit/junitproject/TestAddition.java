package Com.junit.junitproject;

public class TestAddition {

}
