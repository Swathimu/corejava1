package corejava;

import java.util.Scanner;

public class ShiftOperator {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int number=s.nextInt();
		int result=number>>1;
		System.out.println(result);
	

	}

}
