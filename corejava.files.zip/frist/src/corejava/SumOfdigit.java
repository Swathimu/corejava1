package corejava;

import java.util.Scanner;

public class SumOfdigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int sum=0;
for(int i=1; i<=5; ++i) {
	sum=sum+i;
}
System.out.println("sum of 5 number is:"+sum);


	}

}
