package corejava;

public class Oopsconpects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
