package corejava;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int no1=25;
      int no2=40;
      int sum;
      sum=no1+no2;
      System.out.println("sum"+sum);
	}

}
