package corejava;

public class Switch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int avg=50;
int grade=avg/10;
switch(grade) {
case 9:
	System.out.println("9");
    break;
    case 8:
System.out.println("8");
break;
    case 7:
    	System.out.println("6");
    	break;
    	default:
    		System.out.println("fail");
    	
}
	}

}
