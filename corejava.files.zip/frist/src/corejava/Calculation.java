package corejava;

public class Calculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1=8 ,n2=4, sum,mul,div,sub;
		   sum=n1+n2;
		   sub=n1-n2;
		   mul= n1*n2;
		   div=n1/n1 ;
		   int mod = n1%n2;
		   System.out.println("n1 = 8 ,n2 = 4");
		   System.out.println("Addition of two numbers is "+n1+" and "+n2+":"+sum);
		   System.out.println("Subtraction = "+sub);
		   System.out.println("Multiplication = "+mul);
		   System.out.println("Division = "+div);
		   System.out.println("Mod = "+mod);

	}

}
