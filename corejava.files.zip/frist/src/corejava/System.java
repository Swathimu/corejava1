package corejava;

public class System {

}
