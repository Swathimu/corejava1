package corejava;

 class Bike {
	final void run() {System.out.println("running");
	}
	}
class Honda extends Bike {
 {System.out.println("running safely with 100kmph");
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Honda honda=new Honda();
honda.run();
	}

}
