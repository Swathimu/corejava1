package corejava;
import java.util.Scanner;
public class Multiply {

	public static void main(String[] args) {
		// TODO Auto-generated m
		Scanner sc=new Scanner(System.in);
		System.out.print("enter numer:");
		int n=sc.nextInt();
		for(int i=1;i<=10;++i) {
			System.out.println(n+"*"+i+"*"+n*i);
	
}
	}

}
