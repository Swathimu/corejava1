package corejava;

public class Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Double n1=-2.2,n2=5.5,n3=-4.5, largestNumber;
if (n1 >= n2) {
	largestNumber=n1;
}
	else {
	largestNumber=n3;{
}
	 {
		if(n2>=n3) {
			largestNumber=n2;
		}else {
			largestNumber=n3;
		}
	}
	System.out.println("Largest number is"+largestNumber);
			
	
	

	}

}
}