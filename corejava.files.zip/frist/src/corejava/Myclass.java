package corejava;

abstract class Arithmatic {
abstract void calculate(double x);
}
class Square extends Arithmatic
{
	void calculate(double x)
	{
		System.out.println("Square"+(x*x));
}
}
class SquareRoot extends Arithmatic
{
	void calculate(double x)
	{
		System.out.println("squareRoot"+Math.sqrt(x));
	}
}
class Myclass
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Square object1=new Square();
object1.calculate(4);
SquareRoot object2=new SquareRoot();
object2.calculate(4);
Arithmatic reference;
reference=object1;
object1.calculate(5);
}

}
