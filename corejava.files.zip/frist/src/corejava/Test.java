package corejava;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Integer iob=100;
int i=iob;
System.out.println(i+""+iob);	
	Character cob='a';
	char ch=cob;
	System.out.println(cob+""+ch);
	}

}
