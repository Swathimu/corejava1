package corejava;

public class WhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=0,sum=0;
while(i<=10)
{
	sum+=i;
	i++;
	
}
System.out.println("Sum:"+sum);
	}

}
