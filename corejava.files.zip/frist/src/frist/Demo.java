package frist;



public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
		int a=5,b=5,c;
		c=a+b;
		
	      System.out.println("sum"+c);
	      
	}

}
