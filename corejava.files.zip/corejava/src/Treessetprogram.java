import java.util.*;
public class Treessetprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TreeSet<String>tress=new TreeSet<String>();
tress.add("swathi");
tress.add("rahul");
tress.add("sunitha");
tress.add("narsing");
System.out.println("tress set elements is:"+tress);
tress.pollFirst();
System.out.println("tress after pollfrist:"+tress);
tress.pollLast();
System.out.println("tree polllast  is:"+tress);
String s=tress.higher("swathi");
System.out.println("higher:"+s);
String s1=tress.lower("rahul");
System.out.println("lower:"+s1);
Iterator i=tress.descendingIterator();
System.out.println(i.next());
	}

}
